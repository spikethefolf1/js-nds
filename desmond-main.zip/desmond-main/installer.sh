wget https://raw.githubusercontent.com/js-emulators/desmond/main/dist/desmond.min.js
wget https://raw.githubusercontent.com/js-emulators/desmond/main/dist/desmond.wasm
